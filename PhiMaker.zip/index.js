console.clear();
